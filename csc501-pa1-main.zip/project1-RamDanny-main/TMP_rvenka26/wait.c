/* wait.c - wait */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <q.h>
#include <sem.h>
#include <stdio.h>
#include <lab0.h>

/*------------------------------------------------------------------------
 * wait  --  make current process wait on a semaphore
 *------------------------------------------------------------------------
 Tracking id 26
 */
SYSCALL	wait(int sem)
{
	STATWORD ps;    
	struct	sentry	*sptr;
	struct	pentry	*pptr;

	//begin tracking
	extern unsigned long ctr1000;
	unsigned long syscall_start_time = ctr1000, syscall_end_time = 0;
	//end tracking

	disable(ps);
	if (isbadsem(sem) || (sptr= &semaph[sem])->sstate==SFREE) {
		restore(ps);
		if (syscall_is_track) {
			syscall_end_time = ctr1000;
			update_syslog(26, syscall_end_time - syscall_start_time);
		}
		return(SYSERR);
	}
	
	if (--(sptr->semcnt) < 0) {
		(pptr = &proctab[currpid])->pstate = PRWAIT;
		pptr->psem = sem;
		enqueue(currpid,sptr->sqtail);
		pptr->pwaitret = OK;
		resched();
		restore(ps);
		return pptr->pwaitret;
	}
	restore(ps);
	if (syscall_is_track) {
		syscall_end_time = ctr1000;
		update_syslog(26, syscall_end_time - syscall_start_time);
	}
	return(OK);
}
