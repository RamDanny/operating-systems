/* setnok.c - setnok */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <lab0.h>

/*------------------------------------------------------------------------
 *  setnok  -  set next-of-kin (notified at death) for a given process
 *------------------------------------------------------------------------
 Tracking id 14
 */
SYSCALL	setnok(int nok, int pid)
{
	STATWORD ps;    
	struct	pentry	*pptr;

	//begin tracking
	extern unsigned long ctr1000;
	unsigned long syscall_start_time = ctr1000, syscall_end_time = 0;
	//end tracking

	disable(ps);
	if (isbadpid(pid)) {
		restore(ps);
		if (syscall_is_track) {
			syscall_end_time = ctr1000;
			update_syslog(14, syscall_end_time - syscall_start_time);
		}
		return(SYSERR);
	}
	pptr = &proctab[pid];
	pptr->pnxtkin = nok;
	restore(ps);
	if (syscall_is_track) {
			syscall_end_time = ctr1000;
			update_syslog(14, syscall_end_time - syscall_start_time);
		}
	return(OK);
}
