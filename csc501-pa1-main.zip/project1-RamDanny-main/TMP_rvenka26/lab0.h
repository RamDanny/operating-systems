/*lab0.h - zfunction*/

#ifndef _LAB0_H
#define _LAB0_H
//long zfunction(long);
extern int syscall_is_track;
struct proclog {
    int wasactive;
    int syscall_freq[27];
    unsigned long syscall_time_taken[27];
};
extern void syscallsummary_start();
extern void syscallsummary_stop();
extern void update_syslog(int, unsigned long);
extern void printsyscallsummary();
#endif