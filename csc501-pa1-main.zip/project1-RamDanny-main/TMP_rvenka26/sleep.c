/* sleep.c - sleep */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <q.h>
#include <sleep.h>
#include <stdio.h>
# include <lab0.h>

/*------------------------------------------------------------------------
 * sleep  --  delay the calling process n seconds
 *------------------------------------------------------------------------
 Tracking id 18
 */
SYSCALL	sleep(int n)
{
	//begin tracking
	extern unsigned long ctr1000;
	unsigned long syscall_start_time = ctr1000, syscall_end_time = 0;
	//end tracking
	
	STATWORD ps;    
	if (n<0 || clkruns==0) {
		if (syscall_is_track) {
			syscall_end_time = ctr1000;
			update_syslog(18, syscall_end_time - syscall_start_time);
		}
		return(SYSERR);
	}
	if (n == 0) {
	        disable(ps);
		resched();
		restore(ps);
		if (syscall_is_track) {
			syscall_end_time = ctr1000;
			update_syslog(18, syscall_end_time - syscall_start_time);
		}
		return(OK);
	}
	while (n >= 1000) {
		sleep10(10000);
		n -= 1000;
	}
	if (n > 0)
		sleep10(10*n);
	if (syscall_is_track) {
			syscall_end_time = ctr1000;
			update_syslog(18, syscall_end_time - syscall_start_time);
	}
	return(OK);
}
