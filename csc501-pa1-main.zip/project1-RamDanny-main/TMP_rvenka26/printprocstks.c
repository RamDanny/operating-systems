/* printprocstks.c - */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>

volatile unsigned long *esp;
volatile unsigned long *ebp;

void printprocstks(int priority) {
    kprintf("void printprocstks(int priority)\n");
    int nproc = NPROC;
    struct pentry *pr;
    int i = 0;
    while (i < nproc) {
        pr = &proctab[i];
        if (pr->pprio > priority) {
            if (pr->pstate == PRCURR) {
                asm("movl %esp, esp");
		        asm("movl %ebp, ebp");
                kprintf("Process [%s]\n\tpid: %d\n\tpriority: %d\n\tbase: 0x%x\n\tlimit: 0x%x\n\tlen: %x\n\tpointer: 0x %x\n", pr->pname, currpid, pr->pprio, ebp, pr->plimit, pr->pstklen, esp);
            }
            else if (pr->pstate == PRREADY) {
                kprintf("Process [%s]\n\tpid: %d\n\tpriority: %d\n\tbase: 0x%x\n\tlimit: 0x%x\n\tlen: %x\n\tpointer: 0x %x\n", pr->pname, i, pr->pprio, pr->pbase, pr->plimit, pr->pstklen, pr->pesp);
            }
        }
        i++;
    }
}