/* setdev.c - setdev */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <lab0.h>

/*------------------------------------------------------------------------
 *  setdev  -  set the two device entries in the process table entry
 *------------------------------------------------------------------------
 Tracking id 13
 */
SYSCALL	setdev(int pid, int dev1, int dev2)
{
	short	*nxtdev;

	//begin tracking
	extern unsigned long ctr1000;
	unsigned long syscall_start_time = ctr1000, syscall_end_time = 0;
	//end tracking

	if (isbadpid(pid)) {
		if (syscall_is_track) {
			syscall_end_time = ctr1000;
			update_syslog(13, syscall_end_time - syscall_start_time);
		}
		return(SYSERR);
	}
	nxtdev = (short *) proctab[pid].pdevs;
	*nxtdev++ = dev1;
	*nxtdev = dev2;
	if (syscall_is_track) {
		syscall_end_time = ctr1000;
		update_syslog(13, syscall_end_time - syscall_start_time);
	}
	return(OK);
}
