/* sreset.c - sreset */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <q.h>
#include <sem.h>
#include <stdio.h>
#include <lab0.h>

/*------------------------------------------------------------------------
 *  sreset  --  reset the count and queue of a semaphore
 *------------------------------------------------------------------------
 Tracking id 22
 */
SYSCALL sreset(int sem, int count)
{
	STATWORD ps;    
	struct	sentry	*sptr;
	int	pid;
	int	slist;

	//begin tracking
	extern unsigned long ctr1000;
	unsigned long syscall_start_time = ctr1000, syscall_end_time = 0;
	//end tracking

	disable(ps);
	if (isbadsem(sem) || count<0 || semaph[sem].sstate==SFREE) {
		restore(ps);
		if (syscall_is_track) {
			syscall_end_time = ctr1000;
			update_syslog(22, syscall_end_time - syscall_start_time);
		}
		return(SYSERR);
	}
	sptr = &semaph[sem];
	slist = sptr->sqhead;
	while ((pid=getfirst(slist)) != EMPTY)
		ready(pid,RESCHNO);
	sptr->semcnt = count;
	resched();
	restore(ps);
	if (syscall_is_track) {
		syscall_end_time = ctr1000;
		update_syslog(22, syscall_end_time - syscall_start_time);
	}
	return(OK);
}
