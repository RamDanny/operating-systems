/* printsyscallsummary.c - */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include "lab0.h"

int NUM_SYSCALLS = 27;
int syscall_is_track;
struct proclog processes[1000];
char syscall_name[27][20] = {"freemem", "chprio", "getpid", "getprio", "gettime", "kill", "receive", "recvclr", "recvtim", "resume", "scount", "sdelete", "send", "setdev", "setnok", "screate", "signal", "signaln", "sleep", "sleep10", "sleep100", "sleep1000", "sreset", "stacktrace", "suspend", "unsleep", "wait"};

void syscallsummary_start() {
    syscall_is_track = 1;
    int i = 1, j = 0;
    for (i = 1; i < 1000; i++) {
        for (j = 0; j < NUM_SYSCALLS; j++) {
            processes[i].syscall_freq[j] = 0;
            processes[i].syscall_time_taken[j] = 0;
        }
    }
}

void syscallsummary_stop() {
    syscall_is_track = 0;
}

void update_syslog(int trackingid, unsigned long sctime) {
    if (currpid > 0) { // if parent process calling syscall is valid
        processes[currpid].wasactive = 1;
        processes[currpid].syscall_freq[trackingid]++;
        processes[currpid].syscall_time_taken[trackingid] += sctime;
    }
}

void printsyscallsummary() {
    kprintf("void printsyscallsummary()");
    int i = 1, j = 0;
    for (i = 1; i < 1000; i++) {
        if (processes[i].wasactive) {
            kprintf("\nProcess [pid:%d]", i);
            for (j = 0; j < NUM_SYSCALLS; j++) {
                if (processes[i].syscall_freq[j] > 0) {
                    kprintf("\n\t Syscall: sys_%s, count: %d, average execution time: %d (ms)", syscall_name[j], processes[i].syscall_freq[j], (int)(processes[i].syscall_time_taken[j] / processes[i].syscall_freq[j]));
                }
            }
        }
    }
    kprintf("\n");
}
