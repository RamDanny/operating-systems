/* send.c - send */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <lab0.h>

/*------------------------------------------------------------------------
 *  send  --  send a message to another process
 *------------------------------------------------------------------------
 Tracking id 12
 */
SYSCALL	send(int pid, WORD msg)
{
	STATWORD ps;    
	struct	pentry	*pptr;

	//begin tracking
	extern unsigned long ctr1000;
	unsigned long syscall_start_time = ctr1000, syscall_end_time = 0;
	//end tracking

	disable(ps);
	if (isbadpid(pid) || ( (pptr= &proctab[pid])->pstate == PRFREE)
	   || pptr->phasmsg != 0) {
		restore(ps);
		if (syscall_is_track) {
			syscall_end_time = ctr1000;
			update_syslog(12, syscall_end_time - syscall_start_time);
		}
		return(SYSERR);
	}
	pptr->pmsg = msg;
	pptr->phasmsg = TRUE;
	if (pptr->pstate == PRRECV)	/* if receiver waits, start it	*/
		ready(pid, RESCHYES);
	else if (pptr->pstate == PRTRECV) {
		unsleep(pid);
		ready(pid, RESCHYES);
	}
	restore(ps);
	if (syscall_is_track) {
		syscall_end_time = ctr1000;
		update_syslog(12, syscall_end_time - syscall_start_time);
	}
	return(OK);
}
