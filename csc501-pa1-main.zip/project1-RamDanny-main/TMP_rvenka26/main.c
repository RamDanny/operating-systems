#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <stdio.h>
#include <lab0.h>

/*------------------------------------------------------------------------
 *  main  --  user main program
 *------------------------------------------------------------------------
 */

int prX;
void halt();

int foo(char c) {
    int i;
	sleep(5);
}

int prch(char c) {
    int i;
    sleep(5);	
}

int main()
{
	//kprintf("\n\nHello CSC 501\n\n"); zfunction(2882400171);
	kprintf("\nTask 1: zfunction\n");
	long zinput = 0xaabbccdd;
	kprintf("Input: %x\n", zinput);
	kprintf("Output: %x\n\n", zfunction(zinput));
	kprintf("\nTask 2: printprocstks\n");
	resume(create(foo, 2000, 15, "proc A", 1, 'A'));
	printprocstks(10);
	kprintf("\nTask 3: printsyscallsummary\n");
	syscallsummary_start();        
    resume(prX = create(prch, 2000, 15, "proc X", 1, 'A'));
    sleep(10);
    syscallsummary_stop();
    printsyscallsummary();
	return 0;
}
