/* scount.c - scount */

#include <conf.h>
#include <kernel.h>
#include <sem.h>
#include <lab0.h>

/*------------------------------------------------------------------------
 *  scount  --  return a semaphore count
 *------------------------------------------------------------------------
 Tracking id 10
 */
SYSCALL scount(int sem)
{
	extern	struct	sentry	semaph[];

	//begin tracking
	extern unsigned long ctr1000;
	unsigned long syscall_start_time = ctr1000, syscall_end_time = 0;
	//end tracking

	if (isbadsem(sem) || semaph[sem].sstate==SFREE) {
		if (syscall_is_track) {
			syscall_end_time = ctr1000;
			update_syslog(10, syscall_end_time - syscall_start_time);
		}
		return(SYSERR);
	}
	if (syscall_is_track) {
		syscall_end_time = ctr1000;
		update_syslog(10, syscall_end_time - syscall_start_time);
	}
	return(semaph[sem].semcnt);
}
