/* frame.c - manage physical frames */
#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <paging.h>

/*-------------------------------------------------------------------------
 * init_frm - initialize frm_tab
 *-------------------------------------------------------------------------
 */
SYSCALL init_frm()
{
    STATWORD ps;
    disable(ps);
    int index =0;
    // initializing all 1024 frames
    while(index < NFRAMES) {
          frm_tab[index].fr_status = FRM_UNMAPPED;
          frm_tab[index].fr_pid = -1;
          frm_tab[index].fr_vpno = -1;
          frm_tab[index].fr_refcnt = 0;
          frm_tab[index].fr_type = FR_PAGE;
          frm_tab[index].fr_dirty = 0;
          index++;
      }
    restore(ps);
    return OK;
}

/*-------------------------------------------------------------------------
 * get_frm - get a free frame according page replacement policy
 *-------------------------------------------------------------------------
 */
SYSCALL get_frm(int* avail)
{
    STATWORD ps;
    disable(ps);
    int index =0;

    // check for a free frame in frame table
    while (index < NFRAMES) {
      if (frm_tab[index].fr_status == FRM_UNMAPPED) {
        *avail = index;
        restore(ps);
        return OK;
      }
      index++;
    }

    // use SC policy to get a free frame
    int frameIndex = get_frame_using_SC_policy();

    // free the frame first and then return it as available frame
    free_frm(frameIndex);
    *avail = frameIndex;

    if(debug_option == 1){
        kprintf("Frame to be removed : %d\n",frameIndex);
    }
    restore(ps);
    return OK;
}

/*-------------------------------------------------------------------------
 * free_frm - free a frame 
 *-------------------------------------------------------------------------
 */
SYSCALL free_frm(int i)
{
    STATWORD ps;
    disable(ps);

    if(i >= 0 && i < NFRAMES){
        // free a frame which is mapped to a page
        if(frm_tab[i].fr_type == FR_PAGE){
            int framePID = frm_tab[i].fr_pid;
            int vpno = frm_tab[i].fr_vpno;
            unsigned long pdbr = proctab[framePID].pdbr;

            // get page directory and page table offsets
            unsigned int pageDirectoryOffset = vpno / 1024;
            unsigned int pageTableOffset = vpno & 1023;

            // get page table entry
            pd_t *pageDirectoryEntry = (pd_t *)(pdbr + pageDirectoryOffset * sizeof(pd_t));
            pt_t *pageTableEntry = (pt_t *)(pageDirectoryEntry->pd_base * NBPG + pageTableOffset * sizeof(pt_t));

            // write back to backing store if the page is dirty
            int bs_id = proctab[framePID].store;
            int pageNumber = vpno - proctab[framePID].vhpno;
            write_bs((i + 1024) * NBPG, bs_id, pageNumber);

            // update the page table entry as page is not present
            pageTableEntry->pt_pres = 0;

            // decrease the reference count of the page table frame
            frm_tab[pageDirectoryEntry->pd_base - 1024].fr_refcnt -= 1;

            // if no more pages are mapped to this page table, unmap the page table
            if (frm_tab[pageDirectoryEntry->pd_base - 1024].fr_refcnt == 0) {
                frm_tab[pageDirectoryEntry->pd_base - 1024].fr_status = FRM_UNMAPPED;
                frm_tab[pageDirectoryEntry->pd_base - 1024].fr_pid = -1;
                frm_tab[pageDirectoryEntry->pd_base - 1024].fr_vpno = -1;  
                frm_tab[pageDirectoryEntry->pd_base - 1024].fr_type = FR_PAGE;
                pageDirectoryEntry->pd_pres = 0;
            }

            // remove the frame from sc_queue 
            remove_frame_from_sc_queue(i);
            restore(ps);
            return OK;
    }
    }
    restore(ps);
    return SYSERR;
}

// initialize sc_queue
void init_sc_queue() {
    sc_queue_size = 0;
    sc_queue_position = 0;
}

// add the frame to sc_queue when it is mapped to a page
void add_frame_to_sc_queue(int frameIndex) {
    sc_queue[sc_queue_size] = frameIndex;
    sc_queue_size = (sc_queue_size + 1) % NFRAMES;
}


void remove_frame_from_sc_queue(int frameIndex) {
    int i;
    for (i = 0; i < sc_queue_size; i++) {
        if (sc_queue[i] == frameIndex) {
            // shifts all the rest of the elements to the left
            int j;
            for (j = i; j < sc_queue_size - 1; j++) {
                sc_queue[j] = sc_queue[j + 1];
            }
            sc_queue_size--;
            return;
        }
    }
}

int get_frame_using_SC_policy(){
    while (1) {
        // get the current queue head
        int frameIndex = sc_queue[sc_queue_position];

        // only free frames which are mapped to pages
        if (frm_tab[frameIndex].fr_type == FR_PAGE) {
            int framePID = frm_tab[frameIndex].fr_pid;
            int vpno = frm_tab[frameIndex].fr_vpno;
            unsigned long pdbr = proctab[framePID].pdbr;

            // get page directory and page table offsets
            int pageDirectoryOffset = vpno / 1024;
            int pageTableOffset = vpno & 1023;

            // get page table entry
            pd_t *pageDirectoryEntry = (pd_t *)(pdbr + pageDirectoryOffset * sizeof(pd_t));
            pt_t *pageTableEntry = (pt_t *)(pageDirectoryEntry->pd_base * NBPG + pageTableOffset * sizeof(pt_t));

            // check if page was accessed
            if (pageTableEntry->pt_acc == 0) {  
                return frameIndex;
            } else {
                // sc policy to give it second chance
                pageTableEntry->pt_acc = 0;
            }
        }
        sc_queue_position = (sc_queue_position + 1) % sc_queue_size;
    }
}

void initPageDirectory(int pid){
    int frameIndex = 0;
    int i=0;
    pd_t *pageDirectoryEntry;

    // get a free frame and map it for page directory
    if(get_frm(&frameIndex) != SYSERR){
        
        proctab[pid].pdbr = (1024+ frameIndex) * NBPG;
        pageDirectoryEntry = proctab[pid].pdbr;
        // fill up the page directory page entries
        while(i < 1024){
            pageDirectoryEntry[i].pd_write = 1;	
            if(i>4){
                pageDirectoryEntry[i].pd_pres = 0;
            } else{
                pageDirectoryEntry[i].pd_pres = 1;
                pageDirectoryEntry[i].pd_base = 1024 + i;
            }	
            i++;
        }

        // update frame table values 
        update_frame_table(frameIndex, FRM_MAPPED, pid, FR_DIR);

    } else {
        kprintf("Error in initializing page directory\n");
    } 
}

//  update frame table values
void update_frame_table(int frameIndex, int fr_status, int pid, int fr_type) {
    frm_tab[frameIndex].fr_status = fr_status;
    frm_tab[frameIndex].fr_pid = pid;
    frm_tab[frameIndex].fr_type = fr_type;
}
