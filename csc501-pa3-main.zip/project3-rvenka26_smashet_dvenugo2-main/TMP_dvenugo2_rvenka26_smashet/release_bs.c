#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <paging.h>

SYSCALL release_bs1(int pid) {

  /* release the backing store with ID bs_id */

int j; 
j = 0;
while(j < NBS) {
  bsm_tab[j].bs_pid[pid] = -1;
  bsm_tab[j].bs_vpno[pid] = -1;
  j += 1;
}

int bs_id, i, flag;
bs_id = 0;
while(bs_id < NBS) {
flag = 0;
  for(i = 0; i < NPROC; i++) {
    if(bsm_tab[bs_id].bs_pid[i] == i) {
      flag = 1;
    }
  }
  if(flag == 0) {
    free_bsm(bs_id);
  }
  bs_id += 1;
}

  return OK;

}


SYSCALL release_bs(bsd_t id) {
  STATWORD ps;
  disable(ps);
  if(id < 0 || id > NBS || bsm_tab[id].bs_pid[currpid] != currpid) {
    restore(ps);
    return(SYSERR);
  } else {
    free_bsm(id);
  }
}
