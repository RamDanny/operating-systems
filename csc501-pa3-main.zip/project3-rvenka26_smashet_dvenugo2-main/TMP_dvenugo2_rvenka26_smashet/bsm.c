/* bsm.c - manage the backing store mapping*/

#include <conf.h>
#include <kernel.h>
#include <paging.h>
#include <proc.h>

/*-------------------------------------------------------------------------
 * init_bsm- initialize bsm_tab
 *-------------------------------------------------------------------------
 */
SYSCALL init_bsm()
{
    STATWORD ps;
    disable(ps);
    int i, proc_i; 
    for(i = 0;  i < NBS; i++) {
        bsm_tab[i].bs_status = BSM_UNMAPPED;
        proc_i = 0;
        while(proc_i < NPROC) {
            bsm_tab[i].bs_pid[proc_i] = -1;
            bsm_tab[i].bs_vpno[proc_i] = -1;
            proc_i += 1;
        }
		bsm_tab[i].bs_npages = 0;
		bsm_tab[i].bs_sem = -1;
        bsm_tab[i].bs_privilege = BSM_PUBLIC;
    }
    restore(ps);
    return OK;
}

/*-------------------------------------------------------------------------
 * get_bsm - get a free entry from bsm_tab 
 *-------------------------------------------------------------------------
 */
SYSCALL get_bsm(int* avail)
{
    STATWORD ps;
    disable(ps);

    int i;
    for(i = 0; i < NBS; i ++) {
        if(bsm_tab[i].bs_status == BSM_UNMAPPED) {
            bsm_tab[i].bs_status == BSM_MAPPED;
            *avail = i;
            restore(ps);
            return OK;
        }
    }

    restore(ps);
    return SYSERR;
}


/*-------------------------------------------------------------------------
 * free_bsm - free an entry from bsm_tab 
 *-------------------------------------------------------------------------
 */
SYSCALL free_bsm(int i)
{
    STATWORD ps;
    disable(ps);

    if(i < 0 || i > NBS) {
        restore(ps);
        return SYSERR;
    }

    bsm_tab[i].bs_status = BSM_UNMAPPED;
    int proc_i = 0;
    while(proc_i < NPROC) {
        bsm_tab[i].bs_pid[proc_i] = -1;
        bsm_tab[i].bs_vpno[proc_i] = -1;
        proc_i += 1;

    }
	bsm_tab[i].bs_npages = 0;
	bsm_tab[i].bs_sem = -1;
	bsm_tab[i].bs_privilege = BSM_PUBLIC;
    restore(ps);
    return OK;
}

/*-------------------------------------------------------------------------
 * bsm_lookup - lookup bsm_tab and find the corresponding entry
 *-------------------------------------------------------------------------
 */
SYSCALL bsm_lookup(int pid, long vaddr, int* store, int* pageth)
{
    STATWORD ps;
    disable(ps);
    int vpno;
    vpno = vaddr / NBPG;

    int i;
    for(i=0; i<NBS; i ++) {
        if(bsm_tab[i].bs_status == BSM_MAPPED && bsm_tab[i].bs_pid[pid] == pid ) {
            *store = i;
            *pageth = vpno - bsm_tab[i].bs_vpno[pid];
            restore(ps);
            return OK;
        }
    }
    restore(ps);
    return SYSERR;

}


/*-------------------------------------------------------------------------
 * bsm_map - add an mapping into bsm_tab 
 *-------------------------------------------------------------------------
 */
SYSCALL bsm_map(int pid, int vpno, int source, int npages)
{   
    STATWORD ps;
    disable(ps);
    
    if(source < 0 || source >= NBS || npages <= 0 || npages > 256) {
        restore(ps);
        return SYSERR;
    }
    bsm_tab[source].bs_status = BSM_MAPPED;
    bsm_tab[source].bs_pid[pid] = pid;
    bsm_tab[source].bs_vpno[pid] = vpno;
	bsm_tab[source].bs_npages = npages;
    proctab[pid].store = source;
    proctab[pid].vhpno = vpno;

    restore(ps);
    return(OK);
}



/*-------------------------------------------------------------------------
 * bsm_unmap - delete an mapping from bsm_tab
 *-------------------------------------------------------------------------
 */
SYSCALL bsm_unmap(int pid, int vpno, int flag)
{
    STATWORD ps;
    disable(ps);

    int lookup, store, pageth;
    lookup = bsm_lookup(pid, vpno * NBPG, &store, &pageth);
    if(lookup == SYSERR){
        restore(ps);
        return SYSERR;
    }
    bsm_tab[store].bs_pid[pid] = -1;
    bsm_tab[store].bs_vpno[pid] = -1;


    int i, check;
    for(i = 0; i < NPROC; i++){
    if(bsm_tab[store].bs_pid[i] != -1) {
      check = 1;
      break;
    }
    }
    if(check == 0) {
        free_bsm(store);
    }

    restore(ps);
    return;
}


void save_to_bs(int prevpid) {
	int i, store, pageth, lookup_result;
	for(i = 0; i < NFRAMES; i++) {
		if(frm_tab[i].fr_pid == prevpid && frm_tab[i].fr_type == FR_PAGE) {
			lookup_result = bsm_lookup(prevpid, frm_tab[i].fr_vpno * NBPG, &store, &pageth);
			if(lookup_result != SYSERR) {
				 write_bs((i + FRAME0) * NBPG, store, pageth);
			}
		} 
	}
}

void read_from_bs(int curr_pid) {
	int i, store, pageth, lookup_result;
	for(i = 0; i < NFRAMES; i++) {
		if(frm_tab[i].fr_pid == curr_pid && frm_tab[i].fr_type == FR_PAGE) {
			lookup_result = bsm_lookup(curr_pid, frm_tab[i].fr_vpno * NBPG, &store, &pageth);
			if(lookup_result != SYSERR) {
				 read_bs((i + FRAME0) * NBPG, store, pageth);
			}
		} 
	}
}