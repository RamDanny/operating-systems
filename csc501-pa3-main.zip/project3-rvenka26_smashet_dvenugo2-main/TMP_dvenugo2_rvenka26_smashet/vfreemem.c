/* vfreemem.c - vfreemem */

#include <conf.h>
#include <kernel.h>
#include <mem.h>
#include <proc.h>
#include <paging.h>

extern struct pentry proctab[];
/*------------------------------------------------------------------------
 *  vfreemem  --  free a virtual memory block, returning it to vmemlist
 *------------------------------------------------------------------------
 */
SYSCALL	vfreemem(block, size)
	struct	mblock	*block;
	unsigned size;
{
	STATWORD ps;
    disable(ps);
	struct mblock *ptr1, *ptr2;
	unsigned bound1, bound2;
	struct pentry *pptr = &(proctab[currpid]);
	if (size > 0) { // param check
		size = (unsigned int) roundmb(size); // round down to multiple of 8
		// if block in vaddr range
		if ((unsigned)block >= START_VPNO * NBPG && (unsigned)block <= (unsigned)maxaddr) {
			ptr1 = pptr->vmemlist->mnext; // tracks the curr block
			ptr2 = pptr->vmemlist; // tracks the prev block
			// search the sorted list to find position to insert
			while (ptr1 != (struct mblock *) NULL && ptr1 < block) {
				ptr2 = ptr1;
				ptr1 = ptr1->mnext;
			}
			// check if curr and prev don't overlap with block
			bound1 = (unsigned)block + size;
			bound2 = (unsigned)ptr2 + ptr2->mlen;
			if ((bound2 <= (unsigned)block || ptr2 == pptr->vmemlist) && (bound1 <= (unsigned)ptr1 || ptr1 == NULL)) {
				// coalesce if block and prev exactly overlap
				if (ptr2 != pptr->vmemlist && bound2 == (unsigned)block) {
					ptr2->mlen += size;
				}
				// insert block into list
				block->mnext = ptr1;
				block->mlen = size;
				ptr2->mnext = block;
				ptr2 = block;
				// coalesce if curr and prev exactly overlap
				if (bound2 == (unsigned)ptr1) {
					ptr2->mlen += ptr1->mlen;
					ptr2->mnext = ptr1->mnext;
				}
			}
			restore(ps);
    		return SYSERR;
		}
		restore(ps);
    	return SYSERR;
	}
	restore(ps);
    return SYSERR;
	//kprintf("To be implemented!\n");
	//return(OK);
}