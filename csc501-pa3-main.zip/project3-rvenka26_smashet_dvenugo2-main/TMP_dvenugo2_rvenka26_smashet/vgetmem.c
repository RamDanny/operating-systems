/* vgetmem.c - vgetmem */

#include <conf.h>
#include <kernel.h>
#include <mem.h>
#include <proc.h>
#include <paging.h>

extern struct pentry proctab[];
/*------------------------------------------------------------------------
 * vgetmem  --  allocate virtual heap storage, returning lowest WORD address
 *------------------------------------------------------------------------
 */
WORD	*vgetmem(nbytes)
	unsigned nbytes;
{
	STATWORD ps;
    disable(ps);
	struct mblock *ptr1, *ptr2, *newelt;
	struct pentry *pptr = &(proctab[currpid]);
	if (nbytes > 0) { // param check
		nbytes = (unsigned int) roundmb(nbytes); // round down to multiple of 8
		// if free mem left in vheap
		if (pptr->vmemlist->mnext != (struct mblock *) NULL) {
			ptr1 = pptr->vmemlist->mnext; // tracks the curr block
			ptr2 = pptr->vmemlist; // tracks the prev block
			// search for the first free block >= nbytes
			while (ptr1 != (struct mblock *) NULL) {
				if (ptr1->mlen == nbytes) {
					// remove elt from list
					ptr2->mnext = ptr1->mnext;
					restore(ps);
    				return (WORD *)ptr1;
				}
				else if (ptr1->mlen > nbytes) {
					// reduce elt length by nbytes
					newelt = (struct mblock *)((unsigned)ptr1 + nbytes);
					newelt->mnext = ptr1->mnext;
					newelt->mlen = ptr1->mlen - nbytes;
					ptr2->mnext = newelt;
					restore(ps);
    				return (WORD *)ptr1;
				}
				ptr2 = ptr1;
				ptr1 = ptr1->mnext;
			}
			restore(ps);
    		return (WORD *)SYSERR;
		}
		restore(ps);
    	return (WORD *)SYSERR;
	}
	restore(ps);
    return (WORD *)SYSERR;
	//kprintf("To be implemented!\n");
	//return( SYSERR );
}