/* vcreate.c - vcreate */
    
#include <conf.h>
#include <i386.h>
#include <kernel.h>
#include <proc.h>
#include <sem.h>
#include <mem.h>
#include <io.h>
#include <paging.h>

/*
static unsigned long esp;
*/

LOCAL	newpid();
/*------------------------------------------------------------------------
 *  create  -  create a process to start running a procedure
 *------------------------------------------------------------------------
 */
SYSCALL vcreate(procaddr,ssize,hsize,priority,name,nargs,args)
	int	procaddr;		/* procedure address		*/
	int	ssize;			/* stack size in words		*/
	int	hsize;			/* virtual heap size in pages	*/
	int	priority;		/* process priority > 0		*/
	char	name;			/*  name (for debugging)		*/
	int	nargs;			/* number of args that follow	*/
	long	args;			/* arguments (treated like an	*/
					/* array in the code)		*/
{
	STATWORD ps;
    disable(ps);
	// create process using normal create
	int procid = create(procaddr, ssize, priority, name, nargs, args);
	struct pentry *pptr = &(proctab[procid]);
	int bs = -1;
	struct mblock *first_vheap_block;
	// then assign private heap
	if (get_bsm(&bs) != SYSERR) {
		int vpno = START_VPNO;
		if (bsm_map(procid, vpno, bs, hsize) != SYSERR)
		{
			pptr->vhpnpages = hsize; // no. of pages in vheap
			// initialize vheap free list
			pptr->vmemlist->mnext = (struct mblock *) (START_VPNO * NBPG );
			pptr->vmemlist->mlen = 0;
			// Manually initialize the first free block at the first pg of the vheap
			first_vheap_block = BACKING_STORE_BASE + (bs * BACKING_STORE_UNIT_SIZE);
			first_vheap_block->mnext = NULL;
			first_vheap_block->mlen = hsize * NBPG;
			pptr->is_heap_active = 1;
			bsm_tab[bs].bs_privilege = BSM_PRIVATE;
			restore(ps);
    		return procid;
		}
		restore(ps);
    	return SYSERR;
	}
	//kprintf("To be implemented!\n");
	//return OK;
	restore(ps);
    return SYSERR;
}

/*------------------------------------------------------------------------
 * newpid  --  obtain a new (free) process id
 *------------------------------------------------------------------------
 */
LOCAL	newpid()
{
	int	pid;			/* process id to return		*/
	int	i;

	for (i=0 ; i<NPROC ; i++) {	/* check all NPROC slots	*/
		if ( (pid=nextproc--) <= 0)
			nextproc = NPROC-1;
		if (proctab[pid].pstate == PRFREE)
			return(pid);
	}
	return(SYSERR);
}