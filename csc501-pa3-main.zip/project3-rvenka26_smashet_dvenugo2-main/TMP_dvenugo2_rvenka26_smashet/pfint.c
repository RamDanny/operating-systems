/* pfint.c - pfint */

#include <conf.h>
#include <kernel.h>
#include <paging.h>
#include <proc.h>


/*-------------------------------------------------------------------------
 * pfint - paging fault ISR
 *-------------------------------------------------------------------------
 */
int initPageTable(){
    int frameIndex = 0;
    int i = 0;
    pt_t *pageTableEntry;
    unsigned int ptbr;

    // get a free frame for the page table 
    if(get_frm(&frameIndex) != SYSERR){
        
        pageTableEntry = (pt_t*)((1024 + frameIndex) * NBPG);
        // update the page table entries
        while(i< 1024){
            pageTableEntry[i].pt_pres = 0;
            pageTableEntry[i].pt_write = 1;
            pageTableEntry[i].pt_user = 0;
            pageTableEntry[i].pt_pwt = 0;
            pageTableEntry[i].pt_pcd = 0;
            pageTableEntry[i].pt_acc = 0;
            pageTableEntry[i].pt_dirty = 0;		
            pageTableEntry[i].pt_mbz = 0;
			pageTableEntry[i].pt_global = 0;
			pageTableEntry[i].pt_avail = 0;
			pageTableEntry[i].pt_base = 0;
            i++;
        }
        return frameIndex;
    }
    return SYSERR;
}

SYSCALL pfint()
{

  STATWORD ps;
  disable(ps);

  int frameIndex_pt;
  int frameIndex_page;
  int bs_id;
	int pageth;

  // get the fault address
  unsigned long faultAddr = read_cr2();
  virt_addr_t *virtAddr = (virt_addr_t *)&faultAddr;

  // get the page directory entry 
  pd_t *pageDirectoryEntry = (pd_t *)(proctab[currpid].pdbr + virtAddr->pd_offset * sizeof(pd_t));

  // check if the page table is present or not
  if(pageDirectoryEntry->pd_pres == 0){
    // get frame for page table and initialize it
    frameIndex_pt = initPageTable();

    // update the page directory entry to point to this page table
    pageDirectoryEntry->pd_pres = 1;
		pageDirectoryEntry->pd_write = 1;
    pageDirectoryEntry->pd_user = 0;
    pageDirectoryEntry->pd_pwt = 0;
		pageDirectoryEntry->pd_pcd = 0;
		pageDirectoryEntry->pd_acc = 0;
    pageDirectoryEntry->pd_mbz = 0;
    pageDirectoryEntry->pd_fmb = 0;
		pageDirectoryEntry->pd_global = 0;
		pageDirectoryEntry->pd_avail = 0;
		pageDirectoryEntry->pd_base = 1024 + frameIndex_pt;

    // update the frame table map values for this frame 
    update_frame_table(frameIndex_pt, FRM_MAPPED, currpid, FR_TBL);
  }

  // get the page table entry 
  pt_t *pageTableEntry = (pt_t *)(pageDirectoryEntry->pd_base * NBPG + virtAddr->pt_offset * sizeof(pt_t));

  //check if page is present or not
  if(pageTableEntry->pt_pres == 0){
    // get a free frame for the page
    get_frm(&frameIndex_page);
   
    // add the frame which is mapped for page to sc_queue
    add_frame_to_sc_queue(frameIndex_page);

    // update the page table entry to point to this page
    pageTableEntry->pt_pres = 1;
    pageTableEntry->pt_write = 1;
    pageTableEntry->pt_base = 1024 + frameIndex_page;

    // update the frame table map values for this new frame
    update_frame_table(frameIndex_page, FRM_MAPPED, currpid, FR_PAGE);
    frm_tab[frameIndex_page].fr_vpno = faultAddr/NBPG;
    frm_tab[frameIndex_page].fr_dirty = 0;

    // increase the ref count of page diretory entry frame 
    frm_tab[pageDirectoryEntry->pd_base - 1024].fr_refcnt++;

    // get the backing store page correspoing to this page and load it to the page
    bsm_lookup(currpid, faultAddr, &bs_id, &pageth);
    read_bs((char*)((1024 + frameIndex_page) * NBPG), bs_id, pageth);
   
  }
  write_cr3(proctab[currpid].pdbr);	
  restore(ps);
  return OK;
}