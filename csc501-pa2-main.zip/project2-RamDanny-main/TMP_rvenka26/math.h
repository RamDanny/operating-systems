#ifndef _MATH_H_
#define _MATH_H_

extern long RAND_MAX;

extern double log(double);
extern double taylor_log(double);
extern double pow(double, int);
extern double expdev(double);

#endif