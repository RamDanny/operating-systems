/* resched.c  -  resched */

#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <q.h>
#include "math.h"
#include "sched.h"

unsigned long currSP;	/* REAL sp of current process */
extern int ctxsw(int, int, int, int);
/*-----------------------------------------------------------------------
 * resched  --  reschedule processor to highest priority ready process
 *
 * Notes:	Upon entry, currpid gives current process id.
 *		Proctab[currpid].pstate gives correct NEXT state for
 *			current process if other than PRREADY.
 *------------------------------------------------------------------------
 */
int resched()
{
	register struct	pentry	*optr;	/* pointer to old process entry */
	register struct	pentry	*nptr;	/* pointer to new process entry */

	if (getschedclass() == EXPDISTSCHED) {
		double random = expdev(LAMBDA);
		optr = &(proctab[currpid]);
		// insert curr proc into ready queue
		if (optr->pstate == PRCURR) {
			optr->pstate = PRREADY;
			insert(currpid, rdyhead, optr->pprio);
		}
		// find least prio proc > random
		int next = q[rdyhead].qnext;
		while (q[next].qkey < random && q[next].qnext <= NPROC) {
			next = q[next].qnext;
		}
		// switch to new proc
		currpid = next;
		nptr = &(proctab[currpid]);
		nptr->pstate = PRCURR;
		dequeue(next);
		#ifdef	RTCLOCK
		preempt = QUANTUM;		/* reset preemption counter	*/
		#endif
		ctxsw((int)&optr->pesp, (int)optr->pirmask, (int)&nptr->pesp, (int)nptr->pirmask);
		return OK;
	}

	else if (getschedclass() == LINUXSCHED) {
		optr = &(proctab[currpid]);
		// calc goodness of curr proc
		optr->quantum = preempt;
		if (optr->quantum > 0) {
			optr->goodness = optr->quantum + optr->pprio;
		}
		else optr->goodness = 0;
		// check for new epoch
		int i = 0;
		while (i < NPROC && (proctab[i].quantum <= 0 || (proctab[i].pstate != PRCURR && proctab[i].pstate != PRREADY))) i++;
		// new epoch
		if (i == NPROC) {
			i = 0;
			while (i < NPROC) {
				if (proctab[i].pstate != PRFREE) {
					proctab[i].goodness = proctab[i].pprio + proctab[i].quantum;
					proctab[i].quantum = proctab[i].quantum/2 + proctab[i].pprio;
				}
				i++;
			}
		}
		// send curr proc to ready queue
		if (optr->pstate == PRCURR) {
			optr->pstate = PRREADY;
			insert(currpid, rdyhead, optr->pprio);
		}
		// find runnable proc with max good
		int maxgood = 0, maxproc = 0;
		i = 0;
		while (i < NPROC) {
			if ((proctab[i].pstate == PRCURR || proctab[i].pstate == PRREADY) && proctab[i].quantum > 0 && proctab[i].goodness >= maxgood) {
				maxproc = i;
				maxgood = proctab[i].goodness;
			}
			i++;
		}
		// run max good proc
		nptr = &(proctab[maxproc]);
		nptr->pstate = PRCURR;
		currpid = dequeue(maxproc);

		#ifdef	RTCLOCK
		preempt = nptr->quantum;		/* reset preemption counter	*/
		#endif
		ctxsw((int)&optr->pesp, (int)optr->pirmask, (int)&nptr->pesp, (int)nptr->pirmask);
		return OK;
	}

	else {
		/* no switch needed if current process priority higher than next*/

		if ( ( (optr= &proctab[currpid])->pstate == PRCURR) &&
		(lastkey(rdytail)<optr->pprio)) {
			return(OK);
		}
		
		/* force context switch */

		if (optr->pstate == PRCURR) {
			optr->pstate = PRREADY;
			insert(currpid,rdyhead,optr->pprio);
		}

		/* remove highest priority process at end of ready list */

		nptr = &proctab[ (currpid = getlast(rdytail)) ];
		nptr->pstate = PRCURR;		/* mark it currently running	*/
	#ifdef	RTCLOCK
		preempt = QUANTUM;		/* reset preemption counter	*/
	#endif
		
		ctxsw((int)&optr->pesp, (int)optr->pirmask, (int)&nptr->pesp, (int)nptr->pirmask);
		
		/* The OLD process returns here when resumed. */
		return OK;
	}
}
