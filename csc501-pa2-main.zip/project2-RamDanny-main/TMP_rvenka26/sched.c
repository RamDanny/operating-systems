#include <conf.h>
#include <kernel.h>
#include <proc.h>
#include <q.h>
#include "sched.h"

// 0 is default, 1 is exponential, 2 is linux
static int SCHEDPOLICY = 0;

void setschedclass (int sched_class) {
    SCHEDPOLICY = sched_class;
}

int getschedclass() {
    return SCHEDPOLICY;
}
