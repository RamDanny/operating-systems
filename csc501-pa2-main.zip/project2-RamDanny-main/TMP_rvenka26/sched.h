#ifndef _SCHED_H_
#define _SCHED_H_

#define EXPDISTSCHED 1
#define LINUXSCHED 2
#define LAMBDA 0.1

extern void setschedclass (int sched_class);
extern int getschedclass();

#endif